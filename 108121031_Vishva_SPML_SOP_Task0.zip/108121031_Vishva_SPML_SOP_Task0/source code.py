#importing libraries
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import random as rd
from random import choice
df=pd.read_csv("ArmyPerformance.csv")


print(df)
#to find the highest rank
d1=[] #creating an empty list to store the distances of each soldier from origin and assign the candidate with highest distance as the first ranker
for i in range(1000):
    dist1=(df.Strength.at[i])**2+(df.Obedience.at[i])**2+(df.Mobility.at[i])**2
    d1.append(dist1)
ind_d=d1.index(max(d1))
print("index of first ranker is ",ind_d)
#finding the first 100 ranks by finding the distance of each element from the first ranker and arranging them in ascending order and extracting the first 100 elements 
d2={}#creating a dictionary of distances with distance as key and index as value to keep distances and index always clubbed when sorting
for i in range(1000):
    dist2=(df.Strength.at[i]-df.Strength.at[458])**2 + (df.Obedience.at[i]-df.Obedience.at[458])**2 + (df.Mobility.at[i]-df.Mobility.at[458])**2
    d2[dist2]=i
count=0
fhi=[]#list to store first hundred elements
for i in sorted(d2):
    if count<100:
        fhi.append(d2[i])
        count+=1
print("THE INDEXES OF FIRST 100 RANKERS ARE :\n")
print(fhi)
print("\n\n\n")
#plotting first 100 ranks
plt.figure(figsize=(10,8))
ax=plt.axes(projection='3d')
for z in range(len(fhi)):
    fg=ax.scatter3D(df.iloc[fhi[z],0],df.iloc[fhi[z],1],df.iloc[fhi[z],2],c='r')
fg=ax.scatter3D(df.iloc[458,0],df.iloc[458,1],df.iloc[458,2],c='y')

#droppingthe first 100 ranks from the dataset
df.drop(fhi,axis=0,inplace=True)
#reseting the index
df = df.reset_index()
#generating two centroids for the remaining elements and clustering
c=[rd.randint(0,900),rd.randint(0,900)]#generating random points as centroids
clst1=[]#creating empty lists to contain clusters
clst2=[]

iters=300
#k=3
for i in range(0,900):
    dist=[]#list to store distances of each element from centoids
    for j in range(2):
        d=(df.Strength.at[i]-df.Strength.at[c[j]])**2 + (df.Obedience.at[i]-df.Obedience.at[c[j]])**2 + (df.Mobility.at[i]-df.Mobility.at[c[j]])**2
        dist.append(d)
    ind=dist.index(min(dist))
    #storing index of the data into different clusters
    if ind==0:
        clst1.append(i)#clustering based on the minimum distance
    elif ind==1:
        clst2.append(i)
    
#to find new centroid
for i in range(iters):
    strength1=0
    obedience1=0
    mobility1=0
    #new centroid 1
    for j in range(len(clst1)):
        strength1=strength1+df.Strength.at[clst1[j]]
    avgst1=strength1/len(clst1)
    for j in range(len(clst1)):
        obedience1=obedience1+df.Obedience.at[clst1[j]]
    avgob1=obedience1/len(clst1)
    for j in range(len(clst1)):
        mobility1=mobility1+df.Mobility.at[clst1[j]]
    avgmo1=mobility1/len(clst1)
    #new centroid 2
    strength2=0
    obedience2=0
    mobility2=0
    for j in range(len(clst2)):
        strength2=strength2+df.Strength.at[clst2[j]]
    avgst2=strength2/len(clst2)
    for j in range(len(clst2)):
        obedience2=obedience2+df.Obedience.at[clst2[j]]
    avgob2=obedience2/len(clst2)
    for j in range(len(clst2)):
        mobility2=mobility2+df.Mobility.at[clst2[j]]
    avgmo2=mobility2/len(clst2)
    
    st=[avgst1,avgst2]
    ob=[avgob1,avgob2]
    mo=[avgmo1,avgmo2]
    clst1=[]
    clst2=[]
    #clustering the elements to the new centroids
    for k in range(0,900):
        dist=[]
        for j in range(2):
            d=(df.Strength.at[k]-st[j])**2 + (df.Obedience.at[k]-ob[j])**2 + (df.Mobility.at[k]-mo[j])**2
            dist.append(d)
        ind=dist.index(min(dist))
        #storing index of the data into different clusters
        if ind==0:
            clst1.append(k)
        elif ind==1:
            clst2.append(k)
    #repeating this 300 times to get an efficient and reliable data clustering
if((st[0]**2+ob[0]**2+mo[0]**2)>(st[1]**2+ob[1]**2+mo[1]**2)):
    B=clst1
    C=clst2
    print("THE CENTROIDS ARE:\nRANK B: ",[st[0],ob[0],mo[0]],"\nRANK C: ",[st[1],ob[1],mo[1]],"\n" )
else:
    B=clst2
    C=clst1
    print("THE CENTROIDS ARE:\nRANK B: ",[st[1],ob[1],mo[1]],"\nRANK C: ",[st[0],ob[0],mo[0]],"\n" )    
print("Rank B is \n",B,'\n\n\n',"Rank C is \n",C)
#plotting the data

for z in range(len(clst1)):
    fg=ax.scatter3D(df.iloc[clst1[z],0],df.iloc[clst1[z],1],df.iloc[clst1[z],2],c='g')
for z in range(len(clst2)):
    fg=ax.scatter3D(df.iloc[clst2[z],0],df.iloc[clst2[z],1],df.iloc[clst2[z],2],c='b')



plt.show()

                    
                                                            
        
    
        




        
    

    
        



    
